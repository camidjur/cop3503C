#include "Pixels.h"
Pixels::Pixels() {
	red = 0;
	blue = 0;
	green = 0;
}

