#pragma once
using namespace std;
class Pixels
{
public:
	unsigned char red;
	unsigned char green;
	unsigned char blue;
	Pixels();
};

